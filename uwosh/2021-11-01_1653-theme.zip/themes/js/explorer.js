
$(document).ready(function(){
    Explorer.Construct();
    
});


var Explorer = {
    
    base_cls : '.file-explorer',
    get_path : domain + '/manage/theme/explorer',
    form_path : domain + '/manage/theme/explorer',
    themes_path : domain + '/themes/',
    root : '',
    data : [],
    restrictions: '',
    
    Construct : function(){
        console.log('Construct');
        Explorer.GetSource();
    },
    
    GetSource : function(){
        $.get(Explorer.get_path, function(response){
            Explorer.root = response.root;
            Explorer.data = response.contents;
            Explorer.RefreshExplorer();
        });
    },
    
    RefreshExplorer : function(){
        console.log(Explorer.data);
        var form = Explorer.UploadSection(Explorer.data);
        var ul = Explorer.AddSection(Explorer.data);
        $(Explorer.base_cls).empty();
        $(Explorer.base_cls).append(form);
        $(Explorer.base_cls).append(ul);
    },
    
    
    UploadSection : function(results){
        
        var form = $('<form>').attr({'id':'file-explorer-upload','method':'post', 'accept-charset':'utf-8', 'enctype':'multipart/form-data'});
        var label = $('<label>').html('Active Folder: ');
        
        
        var pathname = $('<input>').attr({'id':'file-explorer-upload-pathname', 'type':'text','disabled':'true', 'name': 'file.explorer.upload.pathname'}).val(Explorer.root);
        var path = $('<input>').attr({'id':'file-explorer-upload-path','type':'hidden', 'name': 'file.explorer.upload.path'}).val(Explorer.root);
        var upload_help = $('<span>').addClass('file-explorer-allowed').html("Allowed File Types?").attr('title',Explorer.restrictions);
        
        var upload_div = $('<div>');
        var upload_label = $('<label>').html('Upload File: ');
        var upload_browser = $('<input>').attr({'type':'file', 'name': 'file.explorer.upload.file'});
        var upload_submit = $('<input>').attr({'type':'submit', 'name': 'file.explorer.upload.submit', 'value':'Upload'});
        upload_div.append(upload_label).append(upload_browser).append(upload_submit);
        
        var newfile_div = $('<div>');
        var newfile_label = $('<label>').html('Create File: ');
        var newfile = $('<input>').attr({'type':'text', 'placeholder':'e.g. mystyle.css', 'name': 'file.explorer.new.filename'});
        var newfile_submit = $('<input>').attr({'type':'submit', 'name': 'file.explorer.new.submit', 'value': 'Create'});
        newfile_div.append(newfile_label).append(newfile).append(newfile_submit);
        
        form.append(label);
        form.append(path);
        form.append(pathname);
        form.append(upload_help);
        form.append(upload_div);
        form.append(newfile_div);
        
        return form;
    },
    
    
    AddSection : function(results){
        
        var ul = $('<ul>');
        for(var i in results){
            var li = $('<li>');
            if (results[i].type == 'Folder'){
                li.addClass('type-folder');
                li.attr('data-path', results[i].web_path);
                li.attr('data-pathname', results[i].short_path);
                li.html(results[i].name);
                li.on('click', function(){
                    $(this).next().toggle();
                    $(this).toggleClass('open');
                    $('li').removeClass('file-explorer-upload-target');
                    $(this).addClass('file-explorer-upload-target');
                    $('#file-explorer-upload-path').val($(this).attr('data-path'));
                    $('#file-explorer-upload-pathname').val($(this).attr('data-pathname'));
                });
                ul.append(li);
                ul.append(Explorer.AddSection(results[i].contents));
            }
            else {
                var a = $('<a>').html(results[i].name).attr({'href': domain + '/manage/theme/editor?path=' + results[i].web_path, 'target':'_blank'});
                var img = $('<img>').attr({'src':Explorer.themes_path + '/images/pencil.png', 'alt':'Edit'});
                a.append(img);
                li.append(a);
                ul.append(li);
            }
        }
        return ul;
    },
    
    
    
    
}